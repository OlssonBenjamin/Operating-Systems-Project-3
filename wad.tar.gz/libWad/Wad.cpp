#include "Wad.h"
#include <fstream>
#include <algorithm>


Wad::Wad()
{
	root = nullptr;
	magic = "";
}

Wad::Wad(Node* set_root, std::string set_magic)
{
	root = new Node(set_root->is_directory, set_root->size, set_root->data, set_root->name, set_root->path, set_root->children);
	magic = set_magic;
}

Node* Wad::getRoot()
{
	return root;
}

Wad* Wad::loadWad(const std::string &path) 
{
	Wad* loaded_wad = new Wad;
	std::ifstream wad_file(path, std::ios::binary);
	loaded_wad->readMagicAsString(wad_file);
	int num_lumps = getFourBytesAsInt(path, 4);
	int directory_offset = getFourBytesAsInt(path, 8);
	Node* root = new Node(true, 0, "/", "/");
	for (int i = 0; i < num_lumps; i++) 
	{
		int lump_position = getFourBytesAsInt(path, directory_offset + (i * 16));
		int lump_size = getFourBytesAsInt(path, directory_offset + 4 + (i * 16));
		std::string lump_name;
		readLumpName(path, directory_offset + 8 + (i * 16), lump_name);
		Node next_lump(true, 0, "/", "/");
		if (lump_size == 0)
			next_lump = directoryLumpToNode(path, directory_offset, i, lump_name, "");
		else
			next_lump = contentLumpToNode(path, lump_position, lump_size, lump_name, "");
		root->children.push_back(next_lump);
	}
	loaded_wad->setRoot(root);
	return loaded_wad;
}

void Wad::readMagicAsString(std::ifstream &file) 
{
	std::vector<char> magic_buffer(4);
	file.read(&magic_buffer.front(), 4);
	magic = std::string(magic_buffer.begin(), magic_buffer.end());
	return;
}

int Wad::getFourBytesAsInt(const std::string &path, int position_in_file)
{
	std::ifstream file(path, std::ios::binary);
	int num_descriptor;
	file.seekg(position_in_file);
	file.read(reinterpret_cast<char*>(&num_descriptor), 4);
	return num_descriptor;
}

void Wad::readLumpName(const std::string &path, int position_in_file, std::string &name) 
{
	std::ifstream file(path, std::ios::binary);
	file.seekg(position_in_file, std::ios::beg);
	std::vector<char> name_buffer(8);
	file.read(&name_buffer.front(), 8);
	name = std::string(name_buffer.begin(), name_buffer.end());
	while (name.back() == '\0')
		name.pop_back();
	return;
}

Node Wad::contentLumpToNode(const std::string &path, int lump_position, int lump_size, std::string lump_name, std::string lump_path)
{
	std::ifstream file(path, std::ios::binary);
	char* data_ptr = new char[lump_size];
	file.seekg(lump_position);
	file.read(data_ptr, lump_size);
	std::vector<char> data_vector(data_ptr, data_ptr + lump_size);
	delete[] data_ptr;
	Node lump(false, lump_size, data_vector, lump_name, (lump_path + "/" + lump_name));
	return lump;
}

Node Wad::directoryLumpToNode(const std::string &path, int lump_position, int &place_keeper, std::string lump_name, std::string lump_path)
{
	place_keeper++;
	int temp_place_keeper = place_keeper;
	Node directory_lump(true, 0, lump_name, (lump_path + "/" + lump_name));
	if (lump_name.size() >= 3) 
		if (lump_name[0] == 'E' && lump_name[2] == 'M')
			mapMarkerToNode(directory_lump, path, lump_position, place_keeper, lump_name, lump_path);
		else
			namespaceMarkerToNode(directory_lump, path, lump_position, place_keeper, lump_name, lump_path);
	return directory_lump;
}

void Wad::mapMarkerToNode(Node &directory_node, const std::string &path, int lump_position, int &place_keeper, std::string lump_name, std::string lump_path) 
{
	int temp_place_keeper = place_keeper;
	for (place_keeper; place_keeper < temp_place_keeper + 10; place_keeper++)
	{
		int next_lump_position = getFourBytesAsInt(path, lump_position + (place_keeper * 16));
		int next_lump_size = getFourBytesAsInt(path, lump_position + 4 + (place_keeper * 16));
		std::string next_lump_name;
		readLumpName(path, lump_position + 8 + (place_keeper * 16), next_lump_name);
		Node next_lump(true, 0, "/", "/");
		if (next_lump_size == 0)
			next_lump = directoryLumpToNode(path, lump_position, place_keeper, next_lump_name, directory_node.path);
		else
			next_lump = contentLumpToNode(path, lump_position, next_lump_size, next_lump_name, directory_node.path);
		directory_node.children.push_back(next_lump);
	}
	place_keeper--;
}

void Wad::namespaceMarkerToNode(Node &directory_node, const std::string &path, int lump_position, int &place_keeper, std::string lump_name, std::string lump_path) 
{
	std::string namespace_end = lump_name;
	namespace_end.erase(namespace_end.length() - 6);
	directory_node = Node(true, 0, namespace_end, (lump_path + "/" + namespace_end));
	namespace_end += "_END";
	std::string current_lump;
	readLumpName(path, lump_position + 8 + (place_keeper * 16), current_lump);
	while (current_lump.compare(namespace_end) != 0) 
	{
		int next_lump_position = getFourBytesAsInt(path, lump_position + (place_keeper * 16));
		int next_lump_size = getFourBytesAsInt(path, lump_position + 4 + (place_keeper * 16));
		std::string next_lump_name;
		readLumpName(path, lump_position + 8 + (place_keeper * 16), next_lump_name);
		Node next_lump(true, 0, "/", "/");
		if (next_lump_size == 0)
			next_lump = directoryLumpToNode(path, lump_position, place_keeper, next_lump_name, directory_node.path);
		else 
			next_lump = contentLumpToNode(path, lump_position, next_lump_size, next_lump_name, directory_node.path);
		directory_node.children.push_back(next_lump);
		place_keeper++;
		readLumpName(path, lump_position + 8 + (place_keeper * 16), current_lump);
	}
}

Node* Wad::getNodeFromPath(const std::string &path, bool &check_if_found) 
{
	if (root == nullptr)
		return nullptr;
	std::string temp_path = path;
	Node* root_node = new Node(root->is_directory, root->size, root->data, root->name, root->path, root->children);
	bool found_final_node = false;
	if (path.size() <= 1) 
	{
		if (path == "/")
			check_if_found = true;
		return root_node;
	}
	else 
	{
		bool found_node_at_level = false;
		while (temp_path.size() > 0) 
		{
			if (temp_path[0] == '/')
				temp_path.erase(temp_path.begin());
			std::string name_of_node = temp_path.substr(0, temp_path.find('/'));
			for (int j = 0; j < root_node->children.size(); j++)
			{
				if (root_node->children[j].name == name_of_node) 
				{
					Node* child_node = new Node(root_node->children[j].is_directory, root_node->children[j].size, root_node->children[j].data, root_node->children[j].name, root_node->children[j].path, root_node->children[j].children);
					delete root_node;
					root_node = child_node;
					found_node_at_level = true;
					break;
				}
			}
			if (!found_node_at_level) 
			{
				check_if_found = false;
				break;
			}
			for (int k = 0; k < name_of_node.size(); k++)
				temp_path.erase(temp_path.begin());
			if (found_node_at_level && ((temp_path.size() == 0) || (temp_path == "/")))
			{
				found_final_node = true;
				check_if_found = true;
				break;
			}
			found_node_at_level = false;
		}
	}
	return root_node;
}

std::string Wad::getMagic() 
{
	return magic;
}

bool Wad::isDirectory(const std::string &path) 
{
	bool found_node = false;
	Node* found = getNodeFromPath(path, found_node);
	if (found_node) 
		found_node = found->is_directory;
	delete found;
	return found_node;
}

bool Wad::isContent(const std::string &path) 
{
	bool found_node = false;
	Node* found = getNodeFromPath(path, found_node);
	if (found_node)
		found_node = !found->is_directory;
	delete found;
	return found_node;
}

int Wad::getSize(const std::string &path) 
{
	int size = -1;
	bool found_node = false;
	Node* found = getNodeFromPath(path, found_node);
	if (found_node) 
		size = found->size;
	delete found;
	return size;
}

int Wad::getContents(const std::string &path, char *buffer, int length, int offset) 
{
	int size = -1;
	bool found_node = false;
	Node* found = getNodeFromPath(path, found_node);
	if (found_node && !found->is_directory)
	{
		if (offset + length >= found->data.size()) 
		{
			if (offset > found->data.size())
				size = 0;
			else
			{
				std::copy(found->data.begin() + offset, found->data.end(), buffer);
				size = found->data.size() - offset;
			}
		}
		else 
		{
			std::copy(found->data.begin() + offset, found->data.begin() + offset + length, buffer);
			size = length;
		}
	}
	delete found;
	return size;
}

int Wad::getDirectory(const std::string &path, std::vector<std::string> *directory) 
{
	int size = -1;
	bool found_node = false;
	Node* found = getNodeFromPath(path, found_node);
	if (found_node)
		if (found->is_directory) 
		{
			for (int i = 0; i < found->children.size(); i++)
				directory->push_back(found->children[i].name);
			size = found->children.size();
		}
	delete found;
	return size;
}

std::vector<std::string> Wad::getNamesInPath(const std::string &path, bool &check_if_found) 
{
	std::vector<std::string> names;
	if (root == nullptr)
		return names;
	std::string temp_path = path;
	Node* root_node = new Node(root->is_directory, root->size, root->data, root->name, root->path, root->children);
	bool found_final_node = false;
	if (path.size() <= 1)
	{
		if (path == "/") 
		{
			names.emplace_back("/");
			check_if_found = true;
		}
		return names;
	}
	else
	{
		bool found_node_at_level = false;
		while (temp_path.size() > 0)
		{
			if (temp_path[0] == '/')
				temp_path.erase(temp_path.begin());
			std::string name_of_node = temp_path.substr(0, temp_path.find('/'));
			for (int j = 0; j < root_node->children.size(); j++)
			{
				if (root_node->children[j].name == name_of_node)
				{
					names.emplace_back(root_node->children[j].name);
					Node* child_node = new Node(root_node->children[j].is_directory, root_node->children[j].size, root_node->children[j].data, root_node->children[j].name, root_node->children[j].path, root_node->children[j].children);
					delete root_node;
					root_node = child_node;
					found_node_at_level = true;
					break;
				}
			}
			if (!found_node_at_level)
			{
				check_if_found = false;
				break;
			}
			for (int k = 0; k < name_of_node.size(); k++)
				temp_path.erase(temp_path.begin());
			if (found_node_at_level && ((temp_path.size() == 0) || (temp_path == "/")))
			{
				found_final_node = true;
				check_if_found = true;
				break;
			}
			found_node_at_level = false;
		}
	}
	return names;
}

void Wad::deleteNode(const std::string &path)
{
	bool found_node = false;
	std::vector<std::string> name_path = getNamesInPath(path, found_node);
	std::vector<std::string> name_path_copy = name_path;
	if (found_node) 
	{
		std::string node_to_delete = name_path[name_path.size() - 1];
		if (node_to_delete == "/") 
		{
			delete root;
			root = nullptr;
		}
		else 
		{
			std::vector<Node>::iterator it = root->children.begin();
			std::vector<std::vector<Node>> keep_all_children;
			std::vector<int> place_keeper;
			std::vector<Node>& child = root->children;
			int size = root->children.size();
			if (name_path.size() == 2)
			{
				for (it = root->children.begin(); it != root->children.end(); it++)
					if (it->name == name_path[1])
						root->children.erase(it);
			}
			else 
			{
				while (name_path.size() != 1)
				{
					for (int i = 0; i < size; i++)
					{
						if (it->name == name_path[0])
						{
							keep_all_children.emplace_back(child);
							child = it->children;
							it = child.begin();
							size = child.size();
							name_path.erase(name_path.begin());
							place_keeper.emplace_back(i);
							break;
						}
						it++;
					}
				}
				for (int k = 0; k < child.size(); k++) 
				{
					if (it->name == name_path[0])
					{
						child.erase(it);
						keep_all_children.emplace_back(child);
						place_keeper.emplace_back(k);
						break;
					}
					it++;
				}
				for (int j = place_keeper.size() - 1; j > 0; j--) 
				{
					keep_all_children[j - 1][place_keeper[j - 1]].children = keep_all_children[j];
				}
				root->children = keep_all_children[0];
			}
		}
	}
	return;
}

Wad::~Wad()
{
	delete root;
}

void Wad::setRoot(Node* new_root) 
{
	root = new_root;
}

Node::Node(bool check_if_directory, int size_of_lump, std::vector<char> lump_data, std::string name_of_lump, std::string lump_path) 
{
	is_directory = check_if_directory;
	size = size_of_lump;
	data = lump_data;
	name = name_of_lump;
	path = lump_path;
}

Node::Node(bool check_if_directory, int size_of_lump, std::string name_of_lump, std::string lump_path) 
{
	is_directory = check_if_directory;
	size = size_of_lump;
	name = name_of_lump;
	path = lump_path;
}

Node::Node(bool check_if_directory, int size_of_lump, std::vector<char> lump_data, std::string name_of_lump, std::string lump_path, std::vector<Node> children_vector) 
{
	is_directory = check_if_directory;
	size = size_of_lump;
	data = lump_data;
	name = name_of_lump;
	path = lump_path;
	children = children_vector;
}

Node::~Node() 
{}
