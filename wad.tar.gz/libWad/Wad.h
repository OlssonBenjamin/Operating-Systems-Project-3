#pragma once
#include <string>
#include <vector>

struct Node
{
	Node(bool check_if_directory, int size_of_lump, std::vector<char> lump_data, std::string name_of_lump, std::string lump_path);
	Node(bool check_if_directory, int size_of_lump, std::string name_of_lump, std::string lump_path);
	Node(bool check_if_directory, int size_of_lump, std::vector<char> lump_data, std::string name_of_lump, std::string lump_path, std::vector<Node> children_vector);
	~Node();
	bool is_directory;
	int size;
	std::vector<char> data;
	std::string name;
	std::string path;
	std::vector<Node> children;
};

class Wad
{
public:
	static Wad* loadWad(const std::string &path);
	std::string getMagic();
	bool isContent(const std::string &path);
	int getSize(const std::string &path);
	int getContents(const std::string &path, char* buffer, int lenght, int offset = 0);
	int getDirectory(const std::string &path, std::vector<std::string> *directory);
	bool isDirectory(const std::string &path);
	void deleteNode(const std::string &path);
	Node* getRoot();
	Wad();
	Wad(Node* set_root, std::string set_magic);
	~Wad();
private:
	Node* root;
	std::string magic;
	void readMagicAsString(std::ifstream &file);
	static int getFourBytesAsInt(const std::string &path, int position_in_file);
	static void readLumpName(const std::string &path, int position_in_file, std::string &name);
	static Node contentLumpToNode(const std::string &path, int lump_position, int lump_size, std::string lump_name, std::string lump_path);
	static Node directoryLumpToNode(const std::string &path, int lump_position, int &place_keeper, std::string lump_name, std::string lump_path);
	static void mapMarkerToNode(Node &directory_node, const std::string &path, int lump_position, int &place_keeper, std::string lump_name, std::string lump_path);
	static void namespaceMarkerToNode(Node &directory_node, const std::string &path, int lump_position, int &place_keeper, std::string lump_name, std::string lump_path);
	Node* getNodeFromPath(const std::string &path, bool &check_if_found);
	std::vector<std::string> getNamesInPath(const std::string &path, bool &check_if_found);
	void setRoot(Node* root);
};

