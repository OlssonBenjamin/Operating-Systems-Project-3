#define FUSE_USE_VERSION 26
#include <fuse.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <time.h>
#include <string>
#include <vector>
#include <string.h>
#include <iostream>
#include "../libWad/Wad.h"

static Wad* my_wad;

static int getattr_wad(const char *path, struct stat *stbuf)
{
	memset(stbuf, 0, sizeof(struct stat));

	std::string string_path = path;

	stbuf->st_uid = getuid();
	stbuf->st_gid = getgid();

	if (my_wad->isContent(string_path))
	{
		stbuf->st_mode = S_IFREG | 0444;
		stbuf->st_nlink = 1;
		stbuf->st_size = my_wad->getSize(string_path);
		return 0;
	}
	else if (my_wad->isDirectory(string_path))
	{
		stbuf->st_mode = S_IFDIR | 0555;
		stbuf->st_nlink = 2;
		return 0;
	}
	else
		return -ENOENT;
}

static int unlink_wad(const char* path)
{
	std::string string_path = path;

	if (my_wad->isContent(string_path))
	{
		my_wad->deleteNode(string_path);
		return 0;
	}
	else
		return -ENOENT;
}

static int rmdir_wad(const char* path)
{
	std::string string_path = path;

	if (my_wad->isDirectory(string_path))
	{
		std::vector<std::string> directory;
		my_wad->getDirectory(string_path, &directory);
		if (directory.size() == 0)
			my_wad->deleteNode(string_path);
		else
			return -ENOENT;
		return 0;
	}
	else
		return -ENOENT;
}

static int open_wad(const char *path, struct fuse_file_info *fi)
{
	std::string string_path = path;
	if (my_wad->isContent(string_path))
		return 0;
	else
		return -ENOENT;
}

static int read_wad(const char *path, char *buf, size_t size, off_t offset, struct fuse_file_info *fi)
{
	std::string string_path = path;
	if (my_wad->isContent(string_path))
	{
		size_t bytes_read = my_wad->getContents(path, buf, size, offset);
		return bytes_read;
	}
	else
		return -ENOENT;
}

static int readdir_wad(const char *path, void *buf, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi)
{
	std::string string_path = path;
	std::vector<std::string> directory;

	if (my_wad->isDirectory(string_path))
	{
		filler(buf, ".", NULL, 0);
		filler(buf, "..", NULL, 0);
		my_wad->getDirectory(string_path, &directory);
		for (int i = 0; i < directory.size(); i++)
		{
			const char* c_string = directory[i].c_str();
			filler(buf, c_string, NULL, 0);
		}
		return 0;
	}
	else
		return -ENOENT;
}

static int release_wad(const char *path, struct fuse_file_info *fi)
{
	std::string string_path = path;

	if (my_wad->isContent(string_path))
		return 0;
	else
		return -ENOENT;
}

static int releasedir_wad(const char *path, struct fuse_file_info *fi)
{
	std::string string_path = path;
	if (my_wad->isDirectory(string_path))
		return 0;
	else
		return -ENOENT;
}

static int opendir_wad(const char *path, struct fuse_file_info *fi)
{
	std::string string_path = path;
	if (my_wad->isDirectory(string_path))
		return 0;
	else
		return -ENOENT;
}

static struct fuse_operations fuse_example_operations = {
	.getattr = getattr_wad,
	.unlink = unlink_wad,
	.rmdir = rmdir_wad,
	.open = open_wad,
	.read = read_wad,
	.release = release_wad,
	.opendir = opendir_wad,
	.readdir = readdir_wad,
	.releasedir = releasedir_wad,
};

int main(int argc, char *argv[])
{
	if (argc < 3)
		return -1;
	const char* wad_file = argv[1];
	my_wad = Wad::loadWad(wad_file);
	argv[1] = argv[2];
	fuse_main(2, argv, &fuse_example_operations, NULL);
	delete my_wad;
	return 0;
}
